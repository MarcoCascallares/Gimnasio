package gMySql;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
public class MySql {
   
    private static final String db = "gimnasio";
    private static final String user ="root";
    private static final String pass ="";
    private static final String url="jdbc:mysql://localhost:3306/"+db;
    private static Connection con;
    
    public static Connection getConection(){
        try{
            
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url, user, pass);
        }catch(ClassNotFoundException | SQLException e){
            JOptionPane.showMessageDialog(null,"Conexión no establecida: "+ e);
        }
        return con;
    }
    public void cerrarBD() throws SQLException{
        if(!con.isClosed())
            con.close();
    }
}
