/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package formularios;

import java.awt.HeadlessException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import gMySql.*;
import java.sql.Connection;
import java.sql.Statement;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
/**
 *
 * @author Docente
 */
public class frmClientes extends javax.swing.JFrame {

    DefaultTableModel modelo;
    Statement stm;
    Connection conection;
    
    public frmClientes() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        CargarClientes();
        configTabla();
        txtNombre.setEditable(false);
        txtApellido.setEditable(false);
        txtCedula.setEditable(false);
        txtTel.setEditable(false);
        txtFecNac.setEnabled(false);
        txtAltura.setEditable(false); 
        txtPeso.setEditable(false);
        btnActualizar.setEnabled(false);
        btnGuardar.setEnabled(false);
    }
    
    private void Habilitar(){
        txtNombre.setEditable(true);
        txtApellido.setEditable(true);
        txtCedula.setEditable(true);
        txtTel.setEditable(true);
        txtFecNac.setEnabled(true);
        txtAltura.setEditable(true); 
        txtPeso.setEditable(true);
        txtNombre.requestFocus();
        txtApellido.requestFocus();
    }
    
     private void CargarClientes(){
        jtClientes.setAutoResizeMode(0);
        
        
        try {
            conection=MySql.getConection();
            String[] titulos ={"ID", "Nombre", "Apellido","DNI", "Telefono", "Fec. de Nac.", "Peso", "Altura"};
            String sql="SELECT * FROM clientes";
            modelo= new DefaultTableModel(null, titulos);
            stm = conection.createStatement();
            ResultSet rs =stm.executeQuery(sql);
            
            String[] fila = new String[8];
            
            while(rs.next()){
                fila[0]=rs.getString("idclientes");
                fila[1]=rs.getString("nombre");
                fila[2]=rs.getString("apellido");
                fila[3]=rs.getString("cedula");
                fila[4]=rs.getString("telefono");
                fila[5]=rs.getString("fecnac");
                fila[6]=rs.getString("peso");
                fila[7]=rs.getString("altura");
                modelo.addRow(fila);
            }
            jtClientes.setModel(modelo);
            configTabla();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
      private void Limpiar(){
        txtNombre.setText(null);
        txtApellido.setText(null);
        txtCedula.setText(null);
        txtTel.setText(null);
        txtFecNac.setDate(null);
        txtAltura.setText(null); 
        txtPeso.setText(null);
        txtNombre.requestFocus();
        txtApellido.requestFocus();
        
        
    }
       private void configTabla(){
        jtClientes.setAutoResizeMode(0);
        TableColumnModel columnModel = jtClientes.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(40);
        columnModel.getColumn(1).setPreferredWidth(100);
        columnModel.getColumn(2).setPreferredWidth(100);
        columnModel.getColumn(3).setPreferredWidth(70);
        columnModel.getColumn(4).setPreferredWidth(90);
        columnModel.getColumn(5).setPreferredWidth(100);
        columnModel.getColumn(6).setPreferredWidth(85);
        columnModel.getColumn(7).setPreferredWidth(85);
        DefaultTableCellRenderer tcr = new DefaultTableCellRenderer();
        tcr.setHorizontalAlignment(SwingConstants.CENTER);
        jtClientes.getColumnModel().getColumn(0).setCellRenderer(tcr);
        jtClientes.getColumnModel().getColumn(1).setCellRenderer(tcr);
        jtClientes.getColumnModel().getColumn(2).setCellRenderer(tcr);
        jtClientes.getColumnModel().getColumn(3).setCellRenderer(tcr);
        jtClientes.getColumnModel().getColumn(4).setCellRenderer(tcr);
        jtClientes.getColumnModel().getColumn(5).setCellRenderer(tcr);
        jtClientes.getColumnModel().getColumn(6).setCellRenderer(tcr);
        jtClientes.getColumnModel().getColumn(7).setCellRenderer(tcr);
    }

    public static String convertToString(Date Date){
            DateFormat df;
            String fech = null;
            df = new SimpleDateFormat("yyyy-MM-d");
            fech = df.format(Date);
            return fech;
        }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnVolverProf = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        txtFecNac = new com.toedter.calendar.JDateChooser();
        txtCedula = new javax.swing.JTextField();
        lblNombre = new javax.swing.JLabel();
        txtTel = new javax.swing.JTextField();
        lblApellido = new javax.swing.JLabel();
        txtPeso = new javax.swing.JTextField();
        lblCedula = new javax.swing.JLabel();
        txtAltura = new javax.swing.JTextField();
        lblFDeNacimiento = new javax.swing.JLabel();
        btnNuevo = new javax.swing.JButton();
        lblTel = new javax.swing.JLabel();
        btnGuardar = new javax.swing.JButton();
        lblPeso = new javax.swing.JLabel();
        btnActualizar = new javax.swing.JButton();
        lblAltura = new javax.swing.JLabel();
        btnEliminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtClientes = new javax.swing.JTable();
        btnVolverClient = new javax.swing.JButton();

        btnVolverProf.setText("Volver");
        btnVolverProf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverProfActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setBackground(new java.awt.Color(175, 232, 253));
        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel1.setText("Formulario de Clientes");
        jLabel1.setOpaque(true);

        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });

        lblNombre.setBackground(new java.awt.Color(175, 232, 253));
        lblNombre.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblNombre.setText("Nombre");
        lblNombre.setOpaque(true);

        lblApellido.setBackground(new java.awt.Color(175, 232, 253));
        lblApellido.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblApellido.setText("Apellido");
        lblApellido.setOpaque(true);

        lblCedula.setBackground(new java.awt.Color(175, 232, 253));
        lblCedula.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblCedula.setText("Cedula");
        lblCedula.setOpaque(true);

        lblFDeNacimiento.setBackground(new java.awt.Color(175, 232, 253));
        lblFDeNacimiento.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblFDeNacimiento.setText("Fecha de Nacimiento");
        lblFDeNacimiento.setOpaque(true);

        btnNuevo.setText("Nuevo");
        btnNuevo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        btnNuevo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        lblTel.setBackground(new java.awt.Color(175, 232, 253));
        lblTel.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblTel.setText("Telefono");
        lblTel.setOpaque(true);

        btnGuardar.setText("Guardar");
        btnGuardar.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        btnGuardar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        lblPeso.setBackground(new java.awt.Color(175, 232, 253));
        lblPeso.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblPeso.setText("Peso");
        lblPeso.setOpaque(true);

        btnActualizar.setText("Actualizar");
        btnActualizar.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        btnActualizar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });

        lblAltura.setBackground(new java.awt.Color(175, 232, 253));
        lblAltura.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblAltura.setText("Altura");
        lblAltura.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        lblAltura.setOpaque(true);

        btnEliminar.setText("Eliminar");
        btnEliminar.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        btnEliminar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        jtClientes.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jtClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jtClientes.setSelectionBackground(new java.awt.Color(175, 232, 253));
        jtClientes.setSelectionForeground(new java.awt.Color(0, 0, 0));
        jtClientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtClientesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jtClientes);

        btnVolverClient.setText("Volver");
        btnVolverClient.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnVolverClient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverClientActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(btnActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(btnVolverClient)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(96, 96, 96)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(lblApellido, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(lblCedula, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(lblNombre, javax.swing.GroupLayout.Alignment.TRAILING)))
                                .addComponent(lblTel, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(lblPeso, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(lblAltura, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(lblFDeNacimiento, javax.swing.GroupLayout.Alignment.TRAILING))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtNombre)
                                .addComponent(txtTel)
                                .addComponent(txtPeso)
                                .addComponent(txtFecNac, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtApellido)
                                .addComponent(txtCedula)
                                .addComponent(txtAltura, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 486, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(299, 299, 299))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel1)
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblNombre)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblApellido, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(19, 19, 19)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblCedula)
                            .addComponent(txtCedula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtFecNac, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblFDeNacimiento))
                        .addGap(17, 17, 17)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtTel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblTel))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtPeso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblPeso))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtAltura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblAltura))
                        .addGap(34, 34, 34)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnVolverClient))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 389, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
            Limpiar();    
            Habilitar();
            btnGuardar.setEnabled(true);
            btnActualizar.setEnabled(false);
            btnEliminar.setEnabled(false);
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
          try {
            String sql = "INSERT INTO clientes (nombre, apellido, cedula, telefono, fecnac, peso, altura) VALUES (?,?,?,?,?,?,?)";
            PreparedStatement ps =conection.prepareCall(sql);
            ps.setString(1, txtNombre.getText());
            ps.setString(2, txtApellido.getText());
            ps.setString(3, txtCedula.getText());
            ps.setString(4, txtTel.getText());
            ps.setString(5, convertToString(txtFecNac.getDate()));
            ps.setDouble(6, Double.parseDouble(txtPeso.getText()));
            ps.setDouble(7, Double.parseDouble(txtAltura.getText()));
            int n=ps.executeUpdate();

            if(n>0){
                JOptionPane.showMessageDialog(null, "Datos guardados correctamente");
            }
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Error al guardar, verifique "+e.getMessage());
        }
        CargarClientes();
        Limpiar();
    }                                          

    private void btnactualizarActionPerformed(java.awt.event.ActionEvent evt) {                                              
        try {
           int fila;
           String sql;
           
           if (JOptionPane.showConfirmDialog(rootPane, "¿Desea actualizar los datos del registro?",
                "Registro actualizado", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
                    fila =jtClientes.getSelectedRow();
                    sql="UPDATE clientes SET nombre='"+txtNombre.getText()+"',apellido='"+txtApellido.getText()+
                        "',Cedula='"+txtCedula.getText()+
                        "'WHERE idclientes='"+jtClientes.getValueAt(fila, 0)+"'";
                    PreparedStatement ps = conection.prepareCall(sql);
                    int n= ps.executeUpdate();
                if(n>0){
                    CargarClientes();
                    JOptionPane.showMessageDialog(null, "Datos actualizados correctamente");
                }
            }    
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "ERROR  "+e.getMessage());
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
          try {
           int fila;
           String sql;
           
           if (JOptionPane.showConfirmDialog(rootPane, "¿Desea actualizar los datos del registro?",
                "Registro actualizado", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
                    fila =jtClientes.getSelectedRow();
                    sql="UPDATE clientes SET nombre='"+txtNombre.getText()+"',apellido='"+txtApellido.getText()+
                        "',cedula='"+txtCedula.getText()+"',telefono='"+txtTel.getText()+
                        "',fecnac='"+convertToString(txtFecNac.getDate())+
                        "',peso='"+Double.parseDouble(txtPeso.getText())+
                        "',altura='"+Double.parseDouble(txtAltura.getText())+
                        "'WHERE idclientes='"+jtClientes.getValueAt(fila, 0)+"'";
                    PreparedStatement ps = conection.prepareCall(sql);
                    int n= ps.executeUpdate();
                if(n>0){
                    CargarClientes();
                    JOptionPane.showMessageDialog(null, "Datos actualizados correctamente");
                }
            }    
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "ERROR  "+e.getMessage());
        }
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
 try {
           int fila=0;
           String sql;
           if (JOptionPane.showConfirmDialog(rootPane, "¿Desea realmente eliminar el registro?",
                "Eliminación Registro", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
                fila =jtClientes.getSelectedRow();
                sql = "DELETE FROM clientes WHERE idclientes="+jtClientes.getValueAt(fila, 0);
                stm=conection.createStatement();
                int n = stm.executeUpdate(sql);
                if(n>0){
                    CargarCategoria();
                    JOptionPane.showMessageDialog(null, "Registro eliminado correctamente");
                }
           }
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "ERROR, VERIFIQUE:  "+e.getMessage());
        }    }//GEN-LAST:event_btnEliminarActionPerformed

    private void jtClientesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtClientesMouseClicked
        Habilitar();
        btnActualizar.setEnabled(true);
        btnGuardar.setEnabled(false);
        btnEliminar.setEnabled(true);
        if(evt.getButton()==1){
            int fila = jtClientes.getSelectedRow();
            try {
                String sql = "SELECT * FROM clientes WHERE idclientes="+jtClientes.getValueAt(fila, 0);
                stm=conection.createStatement();
                ResultSet rs=stm.executeQuery(sql);
                rs.next();
                txtNombre.setText(rs.getString("nombre"));
                txtApellido.setText(rs.getString("apellido"));
                txtCedula.setText(rs.getString("cedula"));
                txtTel.setText(rs.getString("telefono"));
                txtFecNac.setDate(rs.getDate("fecnac"));
                txtPeso.setText(rs.getString("peso"));
                txtAltura.setText(rs.getString("altura"));
                
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
        }
    }//GEN-LAST:event_jtClientesMouseClicked

    private void btnVolverProfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverProfActionPerformed
        new frmInicio().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnVolverProfActionPerformed

    private void btnVolverClientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverClientActionPerformed
        new frmInicio().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnVolverClientActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmClientes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnVolverClient;
    private javax.swing.JButton btnVolverProf;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jtClientes;
    private javax.swing.JLabel lblAltura;
    private javax.swing.JLabel lblApellido;
    private javax.swing.JLabel lblCedula;
    private javax.swing.JLabel lblFDeNacimiento;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblPeso;
    private javax.swing.JLabel lblTel;
    private javax.swing.JTextField txtAltura;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtCedula;
    private com.toedter.calendar.JDateChooser txtFecNac;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtPeso;
    private javax.swing.JTextField txtTel;
    // End of variables declaration//GEN-END:variables

    private void CargarCategoria() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
